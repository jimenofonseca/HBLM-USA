PLEASE INCLUDE
One file per city and per folder (climate change scenario decade)
The file should have the name of the city followed by '-hour'
the format is .dat


DATA SCHEMA

Ta      C
Gh	<this field is not needed in reality>
FF	<this field is not needed in reality>
RH	%


