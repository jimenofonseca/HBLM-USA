PLEASE INCLUDE
One file per city
The file should have the name of the city
the format is .csv


DATA SCHEMA

building_class	-
city	        -
floor_area	sqft
site_energy	kbtu/yr
site_eui	kbtu/sqft/yr
site_year       -

